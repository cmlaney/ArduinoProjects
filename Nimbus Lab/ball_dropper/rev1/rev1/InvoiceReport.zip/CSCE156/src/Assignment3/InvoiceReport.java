package Assignment3;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class InvoiceReport {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws FileNotFoundException,
			ParseException {
		Scanner sc1 = new Scanner(new File(
				"Persons.dat"));
		Map<String, Person> personHash = new HashMap<String, Person>();
		String personCode = "";
		String line1 = sc1.nextLine();
		DecimalFormat dec = new DecimalFormat("0.00");
		while (sc1.hasNext()) {
			line1 = sc1.nextLine();
			String[] parts1 = line1.split(";");
			personCode = parts1[0];
			String[] name1 = parts1[1].split(",");
			String[] address = parts1[2].split(",");
			String lastName = name1[0];
			String firstName = name1[1];
			String street = address[0];
			String city = address[1];
			String state = address[2];
			String zip = address[3];
			String country = address[4];
			Person person = new Person(personCode, firstName, lastName, street,
					city, state, zip, country);
			person.setPersonCode(personCode);
			person.setLastName(lastName);
			person.setFirstName(firstName);

			person.setStreet(street);
			person.setCity(city);
			person.setState(state);
			person.setZip(zip);
			person.setCountry(country);
			if (parts1.length == 4) {
				person.setEmail(parts1[3]);
			}

			personHash.put(personCode, person);
		}
		List<String> PrimaryContact = new ArrayList<String>();
		HashMap<String, Customer> customerHash = new HashMap<String, Customer>();
		Scanner sc2 = new Scanner(new File(
				"Customers.dat"));
		String line2 = sc2.nextLine();
		int numberOfCustomer = Integer.parseInt(line2);
		for (int i = 0; i < numberOfCustomer; i++) {
			line2 = sc2.nextLine();
			String[] parts2 = line2.split(";");
			String[] address = parts2[4].split(",");
			String customerCode = parts2[0];
			String type = parts2[1];
			String primaryContact = parts2[2].replaceAll("\\s+", "");
			String name = parts2[3];
			String street = address[0];
			String city = address[1];
			String state = address[2];
			String zip = address[3];
			String country = address[4];
			Customer customer = new Customer(customerCode, type,
					primaryContact, name, street, city, state, country);
			customer.setCustomerCode(customerCode);
			customer.setType(type);
			customer.setPrimaryContact(primaryContact);
			customer.setStreet(street);
			customer.setCity(city);
			customer.setState(state);
			customer.setZip(zip);
			customer.setCountry(country);
			PrimaryContact.add(customer.getPrimaryContact());
			customerHash.put(customerCode, customer);
		}
		HashMap<String, Product> productHash = new HashMap<String, Product>();
		Scanner sc3 = new Scanner(new File(
				"Products.dat"));
		String line3 = sc3.nextLine();
		while (sc3.hasNext()) {
			line3 = sc3.nextLine();
			String[] parts3 = line3.split(";");

			String productCode = parts3[0];
			String productName = parts3[2];
			String productType = parts3[1];
			double pricePerUnit = 0.0;
			double serviceFee = 0.0;
			double annualLicenseFee = 0.0;
			String consultantPersonCode = "";
			double hourlyFee = 0.0;
			Product product = new Product(productCode, productType,
					productName, pricePerUnit, serviceFee, annualLicenseFee,
					consultantPersonCode, hourlyFee);
			if (parts3[1].equals("E")) {
				pricePerUnit = Double.parseDouble(parts3[3]);
				product.setPricePerUnit(pricePerUnit);
			} else if (parts3[1].equals("L")) {
				serviceFee = Double.parseDouble(parts3[3]);
				annualLicenseFee = Double.parseDouble(parts3[4]);
				product.setSeriveFee(serviceFee);
				product.setAnnualFee(annualLicenseFee);
			} else {
				consultantPersonCode = parts3[3];
				hourlyFee = Double.parseDouble(parts3[4]);
				product.setHourlyFee(hourlyFee);
			}
			productHash.put(productCode, product);
		}
		Scanner sc4 = new Scanner(new File(
				"Invoices.dat"));
		String line4 = sc4.nextLine();
		System.out.println("Executive Summary Report");
		System.out.println("=========================");
		System.out.println(String.format("%-10s%-50s%-33s%-16s%-11s%-12s%-5s",
				"Invoice", "Customer", "Salesperson", "Subtotal", "Fees",
				"Taxes", "Total"));
		double fees2 = 0.0;
		double total3 = 0.0;
		double sum1 = 0.0;
		double tax1 = 0.0;
		while (sc4.hasNext()) {
			line4 = sc4.nextLine();
			String[] parts4 = line4.split(";");
			String invoiceCode = parts4[0];
			String customerCode = parts4[1];
			String salesmanCode = parts4[2];
			String products = parts4[3];
			String[] productList = products.split(",");
			String productInfo = "";
			String productCode = "";
			@SuppressWarnings("unused")
			String a1 = "";
			double fee1 = 0.0;
			double fees = 0.0;

			double total1 = 0.0;
			double total2 = 0.0;

			double sum = 0.0;

			double complianceFee = 0.0;
			double tax = 0.0;

			if (customerHash.get(customerCode).getType().equals("G")) {
				fees = 125;
			} else {
				fees = 0;
			}

			if (productList.length == 2) {
				for (int i = 0; i < productList.length; i++) {
					productInfo = productList[i];
					String product1[] = productInfo.split(":");
					productCode = product1[0];
					if (productHash.get(productCode).getProductType().equals(
							"E")) {
						double numOfUnits = Double.parseDouble(product1[1]);
						total1 = numOfUnits
								* productHash.get(productCode)
										.getPricePerUnit();
						total2 += total1;
						a1 = String.format("%-9s %-76s %-10s %-5s",
								productCode, productHash.get(productCode)
										.getName()
										+ " ("
										+ numOfUnits
										+ " units @ $"
										+ productHash.get(productCode)
												.getPricePerUnit() + "/unit)",
								"$" + fee1, "$" + dec.format(total1));
						fees += fee1;
						tax = total1 * 0.07;
					} else if (productHash.get(productCode).getProductType()
							.equals("L")) {
						String date1 = product1[1];
						String date2 = product1[2];
						SimpleDateFormat myFormatter = new SimpleDateFormat(
								"yyyy-MM-dd");
						java.util.Date date = myFormatter.parse(date2);
						java.util.Date mydate = myFormatter.parse(date1);
						double day = (date.getTime() - mydate.getTime())
								/ (24 * 60 * 60 * 1000);
						total1 = (day / 365)
								* productHash.get(productCode)
										.getAnnualLicenseFee();
						total2 += total1;
						a1 = String
								.format("%-9s %-76s %-10s %-5s", productCode,
										productHash.get(productCode).getName()
												+ " ("
												+ day
												+ " days @ $"
												+ productHash.get(productCode)
														.getAnnualLicenseFee()
												+ "/yr)", "$"
												+ productHash.get(productCode)
														.getServiceFee(), "$"
												+ dec.format(total1));
						fees += productHash.get(productCode).getServiceFee();
						tax += total1 * 0.0425;
					} else {
						double numOfHours = Double.parseDouble(product1[1]);
						fee1 = 150.0;
						total1 = numOfHours
								* productHash.get(productCode).getHourlyFee();
						total2 += total1;
						a1 = String.format("%-9s %-76s %-10s %-5s",
								productCode, productHash.get(productCode)
										.getName()
										+ " ("
										+ numOfHours
										+ " hrs @ $"
										+ productHash.get(productCode)
												.getHourlyFee() + "/hr)", "$"
										+ fee1, "$" + dec.format(total1));
						fees += fee1;
						tax += total1 * 0.0425;
					}
				}
			} else if (productList.length == 3) {
				for (int i = 0; i < productList.length; i++) {
					productInfo = productList[i];
					String product1[] = productInfo.split(":");
					productCode = product1[0];
					if (productHash.get(productCode).getProductType().equals(
							"E")) {
						double numOfUnits = Double.parseDouble(product1[1]);
						total1 = numOfUnits
								* productHash.get(productCode)
										.getPricePerUnit();
						total2 += total1;
						a1 = String.format("%-9s %-76s %-10s %-5s",
								productCode, productHash.get(productCode)
										.getName()
										+ " ("
										+ numOfUnits
										+ " units @ $"
										+ productHash.get(productCode)
												.getPricePerUnit() + "/unit)",
								"$" + 0.0, "$" + dec.format(total1));
						fees += fee1;
						tax = total1 * 0.07;
					} else if (productHash.get(productCode).getProductType()
							.equals("L")) {
						String date1 = product1[1];
						String date2 = product1[2];
						SimpleDateFormat myFormatter = new SimpleDateFormat(
								"yyyy-MM-dd");
						java.util.Date date = myFormatter.parse(date2);
						java.util.Date mydate = myFormatter.parse(date1);
						double day = (date.getTime() - mydate.getTime())
								/ (24 * 60 * 60 * 1000);
						total1 = (day / 365.0)
								* productHash.get(productCode)
										.getAnnualLicenseFee();
						total2 += total1;
						a1 = String
								.format("%-9s %-76s %-10s %-5s", productCode,
										productHash.get(productCode).getName()
												+ " ("
												+ day
												+ " days @ $"
												+ productHash.get(productCode)
														.getAnnualLicenseFee()
												+ "/yr)", "$"
												+ productHash.get(productCode)
														.getServiceFee(), "$"
												+ dec.format(total1));
						fees += productHash.get(productCode).getServiceFee();
						tax += total1 * 0.0425;
					} else {
						double numOfHours = Double.parseDouble(product1[1]);
						total1 = numOfHours
								* productHash.get(productCode).getHourlyFee();
						total2 += total1;
						a1 = String.format("%-9s %-76s %-10s %-5s",
								productCode, productHash.get(productCode)
										.getName()
										+ " ("
										+ numOfHours
										+ " hrs @ $"
										+ productHash.get(productCode)
												.getHourlyFee() + "/hr)",
								"$" + 150.0, "$" + dec.format(total1));
						fees += fee1 + 150;
						tax += total1 * 0.0425;
					}
				}
			}
			if (customerHash.get(customerCode).getType().equals("G")) {
				complianceFee = 125.00;
			} else {
				complianceFee = 0.00;
			}
			if (customerHash.get(customerCode).getType().equals("G")) {
				tax = 0;
			}
			sum = total2 + complianceFee + tax + fees;

			System.out.println(String.format(
					"%-10s%-50s%-33s%-16s%-11s%-12s%-5s", invoiceCode,
					customerHash.get(customerCode).getName(),
					personHash.get(salesmanCode).getFirstName() + ", "
							+ personHash.get(salesmanCode).getLastName(), "$"
							+ dec.format(total2), "$" + dec.format(fees), "$"
							+ dec.format(tax), "$" + dec.format(sum)));
			fees2 += fees;
			total3 += total2;
			tax1 += tax;
			sum1 = fees2 + total3 + tax1;
		}
		System.out
				.println("==============================================================================================================================================");
		System.out
				.println("TOTALS                                                                                   "
						+ "    $"
						+ dec.format(total3)
						+ "	     $"
						+ dec.format(fees2)
						+ "	$"
						+ dec.format(tax1)
						+ "    $"
						+ dec.format(sum1));
		System.out.println('\n');
		System.out.println("Individual Invoice Detail Reports");
		System.out
				.println("==================================================");
		Scanner sc5 = new Scanner(new File(
				"Invoices.dat"));
		String line5 = sc5.nextLine();
		while (sc5.hasNext()) {
			line5 = sc5.nextLine();
			String[] parts4 = line5.split(";");
			String invoiceCode = parts4[0];
			String customerCode = parts4[1];
			String salesmanCode = parts4[2];
			String products = parts4[3];
			String[] productList = products.split(",");
			String productInfo = "";
			String productCode = "";
			String a1 = "";
			double fee1 = 0.0;
			double fees = 0.0;
			double total1 = 0.0;
			double total2 = 0.0;
			double sum = 0.0;
			double complianceFee = 0.0;
			double tax = 0.0;

			if (customerHash.get(customerCode).getType().equals("G")) {
				fees = 125;
			} else {
				fees = 0;
			}

			System.out.println("Invoice " + invoiceCode);
			System.out.println("========================");
			System.out.println("Salesman: "
					+ personHash.get(salesmanCode).getLastName() + ", "
					+ personHash.get(salesmanCode).getFirstName());
			System.out.println("Customer Info: ");
			System.out.println("  " + customerHash.get(customerCode).getName()
					+ "(" + customerCode + ")");
			System.out.println("  "
					+ personHash.get(
							customerHash.get(customerCode).getPrimaryContact())
							.getLastName()
					+ ", "
					+ personHash.get(
							customerHash.get(customerCode).getPrimaryContact())
							.getFirstName());
			System.out.println("  "
					+ customerHash.get(customerCode).getStreet());
			System.out.println("  " + customerHash.get(customerCode).getCity()
					+ " " + customerHash.get(customerCode).getState() + " "
					+ customerHash.get(customerCode).getZip() + " "
					+ customerHash.get(customerCode).getZip());
			System.out.println("-------------------------------------------");
			System.out.println(String.format("%-9s %-76s %-10s %-5s", "Code",
					"Item", "Fees", "Total"));

			if (productList.length == 2) {
				for (int i = 0; i < productList.length; i++) {
					productInfo = productList[i];
					String product1[] = productInfo.split(":");
					productCode = product1[0];
					if (productHash.get(productCode).getProductType().equals(
							"E")) {
						double numOfUnits = Double.parseDouble(product1[1]);
						total1 = numOfUnits
								* productHash.get(productCode)
										.getPricePerUnit();
						total2 += total1;
						a1 = String.format("%-9s %-76s %-10s %-5s",
								productCode, productHash.get(productCode)
										.getName()
										+ " ("
										+ numOfUnits
										+ " units @ $"
										+ productHash.get(productCode)
												.getPricePerUnit() + "/unit)",
								"$ " + fee1, "$ " + dec.format(total1));
						fees += fee1;
						tax = total1 * 0.07;
					} else if (productHash.get(productCode).getProductType()
							.equals("L")) {
						String date1 = product1[1];
						String date2 = product1[2];
						SimpleDateFormat myFormatter = new SimpleDateFormat(
								"yyyy-MM-dd");
						java.util.Date date = myFormatter.parse(date2);
						java.util.Date mydate = myFormatter.parse(date1);
						double day = (date.getTime() - mydate.getTime())
								/ (24 * 60 * 60 * 1000);
						total1 = (day / 365)
								* productHash.get(productCode)
										.getAnnualLicenseFee();
						total2 += total1;
						a1 = String
								.format("%-9s %-76s %-10s %-5s", productCode,
										productHash.get(productCode).getName()
												+ " ("
												+ day
												+ " days @ $"
												+ productHash.get(productCode)
														.getAnnualLicenseFee()
												+ "/yr)", "$ "
												+ productHash.get(productCode)
														.getServiceFee(), "$ "
												+ dec.format(total1));
						fees += productHash.get(productCode).getServiceFee();
						tax += total1 * 0.0425;
					} else {
						double numOfHours = Double.parseDouble(product1[1]);
						fee1 = 150.0;
						total1 = numOfHours
								* productHash.get(productCode).getHourlyFee();
						total2 += total1;
						a1 = String.format("%-9s %-76s %-10s %-5s",
								productCode, productHash.get(productCode)
										.getName()
										+ " ("
										+ numOfHours
										+ " hrs @ $"
										+ productHash.get(productCode)
												.getHourlyFee() + "/hr)", "$ "
										+ fee1, "$ " + dec.format(total1));
						fees += fee1;
						tax += total1 * 0.0425;
					}
					System.out.println(a1);
				}
			} else if (productList.length == 3) {
				for (int i = 0; i < productList.length; i++) {
					productInfo = productList[i];
					String product1[] = productInfo.split(":");
					productCode = product1[0];
					if (productHash.get(productCode).getProductType().equals(
							"E")) {
						double numOfUnits = Double.parseDouble(product1[1]);
						total1 = numOfUnits
								* productHash.get(productCode)
										.getPricePerUnit();
						total2 += total1;
						a1 = String.format("%-9s %-76s %-10s %-5s",
								productCode, productHash.get(productCode)
										.getName()
										+ " ("
										+ numOfUnits
										+ " units @ $"
										+ productHash.get(productCode)
												.getPricePerUnit() + "/unit)",
								"$ " + 0.0, "$ " + dec.format(total1));
						fees += fee1;
						tax = total1 * 0.07;
					} else if (productHash.get(productCode).getProductType()
							.equals("L")) {
						String date1 = product1[1];
						String date2 = product1[2];
						SimpleDateFormat myFormatter = new SimpleDateFormat(
								"yyyy-MM-dd");
						java.util.Date date = myFormatter.parse(date2);
						java.util.Date mydate = myFormatter.parse(date1);
						double day = (date.getTime() - mydate.getTime())
								/ (24 * 60 * 60 * 1000);
						total1 = (day / 365.0)
								* productHash.get(productCode)
										.getAnnualLicenseFee();
						total2 += total1;
						a1 = String
								.format("%-9s %-76s %-10s %-5s", productCode,
										productHash.get(productCode).getName()
												+ " ("
												+ day
												+ " days @ $"
												+ productHash.get(productCode)
														.getAnnualLicenseFee()
												+ "/yr)", "$ "
												+ productHash.get(productCode)
														.getServiceFee(), "$ "
												+ dec.format(total1));
						fees += productHash.get(productCode).getServiceFee();
						tax += total1 * 0.0425;
					} else {
						double numOfHours = Double.parseDouble(product1[1]);
						total1 = numOfHours
								* productHash.get(productCode).getHourlyFee();
						total2 += total1;
						a1 = String.format("%-9s %-76s %-10s %-5s",
								productCode, productHash.get(productCode)
										.getName()
										+ " ("
										+ numOfHours
										+ " hrs @ $"
										+ productHash.get(productCode)
												.getHourlyFee() + "/hr)",
								"$ " + 150.0, "$ " + dec.format(total1));
						fees += fee1 + 150;
						tax += total1 * 0.0425;
					}
					System.out.println(a1);
				}
			}
			System.out.printf("%107s", "========================");
			System.out.println();
			System.out
					.println("SUB-TOTALS                                                                             "
							+ "$ " + fees + "    " + "$ " + dec.format(total2));
			if (customerHash.get(customerCode).getType().equals("G")) {
				complianceFee = 125.00;
			} else {
				complianceFee = 0.00;
			}
			if (customerHash.get(customerCode).getType().equals("G")) {
				tax = 0;
			}
			System.out
					.println("COMPLIANCE FEE                                                                                   "
							+ " $ " + complianceFee);
			System.out
					.println("TAXES                                                                                         "
							+ "    $ " + dec.format(tax));
			sum = total2 + complianceFee + tax + fees;
			System.out
					.println("TOTAL                                                                                          "
							+ "   $ " + dec.format(sum));
			System.out.println('\n');
		}

	}

}
